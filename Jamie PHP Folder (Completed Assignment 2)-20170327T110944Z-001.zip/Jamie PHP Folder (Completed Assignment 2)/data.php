<?php //data.php
require_once 'login.php'; 
	
// Get values from form
$Fname       = $_POST['bookingname'];
$Caddress       = $_POST['collectionaddress'];	
$Daddress         = $_POST['destinationaddress'];	
$Pnumber       = $_POST['phonenumber'];
$Numofpassengers    = $_POST['numberofpassengers']; 
$Wchair    = $_POST['wheelchair']; 
$Notes    = $_POST['notes']; 


// Insert data into mysql
$sql="INSERT INTO booking (customerName, collectAddress, destinationAddress, phoneNumber, numberOfpassengers, wheelchair, notes, datetimeBookingmade)
VALUES ('$Fname', '$Caddress', '$Daddress', '$Pnumber', '$Numofpassengers', '$Wchair', '$Notes', NOW())";
$result = mysql_query($sql); 

// if successfully insert data into database, displays message "Successful".
if($result){
header('Location: ../thankyou.php');
}
else {
echo "ERROR";
}

// close mysql
mysql_close();
?> 