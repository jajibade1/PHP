<h1 align="center">West Central Taxi Booking Form</h1>
<div id="wrapper"><!-- BEGIN MAIN WRAPPER -->
    
    <section id="top_area">
        
        <article class="box-right">
        
                <form action="script/data.php" method="post">
                
                    <p align="center">
                      <label for="bookingname"><strong>Customer Name:</strong></label>
                      <input name="bookingname" type="text" required="required" id="bookingname" placeholder="forename, surname" size="30" />
                    </p>
                    <p align="center">
                      <label for="collectionaddress"><strong>Collection Address</strong>:</label>
                      <input name="collectionaddress" type="text" required="required" id="collectionaddress" placeholder="Add1, Add2, Postcode" autocomplete="on" size="30" />
                    </p>
                    <p align="center">
                      <label for="destinationaddress"><strong>Destination Address</strong></label>
                      <strong>                      :</strong>
                      <input name="destinationaddress" type="text" required="required" id="destinationaddress" placeholder="Add1, Add2, Postcode" size="30" />
                    </p>
                    <p align="center">
                      <label for="phonenumber"><strong>Phone Number:</strong></label>
                      <input name="phonenumber" type="text" required="required" id="phonenumber" placeholder="Max 12 characters" size="30" maxlength="12" />
                  </p>
                    <p align="center">
                      <label for="numberofpassengers"><strong>Number of Passengers:</strong></label>
                      <select name="numberofpassengers" required="required" id="numberofpassengers">
                        <option selected="selected">Choose:</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10+">10+</option>
                      </select>
                    </p>
                    <p align="center"><label><strong>WheelChair Access?</strong></label>
                      <strong>                      :</strong>
<label>
              <input name="RadioGroup1" type="radio" id="RadioGroup1_0" value="1" />
              Yes</label>
                        <label>
                          <input type="radio" name="RadioGroup1" value="0" id="RadioGroup1_1" />
                          No</label>
<br />
<br />
                      <label for="notes"><strong>Notes:</strong></label>
                        <textarea name="notes" cols="60" rows="5" id="notes" placeholder="if extra notes are required please write them here"></textarea>
                    </p>
                    
                    <p align="center"> 
                        <input value="Submit" type="submit"> 
                      <input type="reset" name="reset" id="reset" value="Reset">
                    </p>      
                              
    			</form>

        </article>
    
    </section>

</div><!-- END MAIN WRAPPER -->