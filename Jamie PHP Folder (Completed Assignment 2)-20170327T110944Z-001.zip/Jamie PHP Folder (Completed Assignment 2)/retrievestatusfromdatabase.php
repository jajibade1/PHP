<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>



<body>
<h1 align="center"><u>Show list of booking statuses</u></h1>
<div align="center">
  <?PHP

$dbhost = 'localhost';
$dbuser = 'stude72_JA';
$dbpass = '=evSe$H(?{+E';
$conn = mysql_connect($dbhost, $dbuser, $dbpass);
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}
$sql = 'SELECT * 
FROM `bookingstatus`';

mysql_select_db('stude72_205ITCW2');
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not get data: ' . mysql_error());
}
while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
    echo "id :{$row['id']}  <br> ".
         "status : {$row['status']} <br> ".
         "--------------------------------<br>";
} 
echo "collected booking statuses data from database successfully\n";
mysql_close($conn);

?>
  
  
</div>
</body>
</html>
