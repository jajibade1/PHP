<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<h1 align="center"><u>Welcome to Jamie's Ajibades URLs and cPanel</u></h1>

<u><h3>My PHP Files</h3></u>

<?php 

echo '<br><a href="http://student72.cucstudents.co.uk/php/Jamie/">Home Index</a><br>';

echo '<br><a href="http://student72.cucstudents.co.uk/php/Jamie/retrievestatusfromdatabase.php/">showing list of statuses (Addtional Entry coding)</a><br>';

echo '<br><a href="http://student72.cucstudents.co.uk/php/Jamie/bookingretrieve.php"> Display customers details and booking information (entry Coding).</a><br>';

echo '<br><a href="http://student72.cucstudents.co.uk/php/Jamie/content.php">This is the booking form (Complex coding)</a><br>';

echo '<br><a href="http://student72.cucstudents.co.uk/php/Jamie/thankyou.php">Thank you message </a><br>';

 ?>
 
 <h1 align="center">Thank you for using my system</h1>
</body>
</html>