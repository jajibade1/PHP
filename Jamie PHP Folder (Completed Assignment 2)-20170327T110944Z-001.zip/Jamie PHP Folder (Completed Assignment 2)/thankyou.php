<div id="wrapper"><!-- BEGIN MAIN WRAPPER -->
    
    
    <!-- TOP AREA -->
    <section id="top_area">
        
        <article class="box-right-thank-you">
            <h2>
            Thank You,
            </h2>
            <p>
            Your details are being processed. Thank you Jamie Ajibade.
            </p>
 			<footer class="article_foot"></footer>
        </article>
    
    </section>
    <!-- END TOP AREA -->
    
</div><!-- END MAIN WRAPPER -->
