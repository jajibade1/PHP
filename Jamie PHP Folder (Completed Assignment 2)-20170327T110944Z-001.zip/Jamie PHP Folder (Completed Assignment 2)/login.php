<?php //login.php
$db_hostname = 'localhost';
$db_database = 'stude72_205ITCW2';
$db_username = 'stude72_JA';
$db_password = '=evSe$H(?{+E';

// Connect to server.
$db_server = mysql_connect($db_hostname, $db_username, $db_password)
    or die("Unable to connect to MySQL: " . mysql_error());
	
// Select the database.
mysql_select_db($db_database)
    or die("Unable to select database: " . mysql_error());

?>